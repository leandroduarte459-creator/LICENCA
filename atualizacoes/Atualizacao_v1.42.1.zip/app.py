import sys
import cs_app
globals().update({k: v for k, v in vars(cs_app).items() if not k.startswith("__")})
if __name__ == "__main__":
    cs_app.iniciar()
