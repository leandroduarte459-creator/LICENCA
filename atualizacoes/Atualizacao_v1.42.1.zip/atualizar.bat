@echo off
chcp 65001 >nul
title Atualizacao 1.42.1 (Troca de NFC-e: cancelamento no prazo ou devolucao) - Cavalcante Solucoes
set "DESTINO=C:\CavalcanteSolucoes"
if not exist "%DESTINO%\app.py" set "DESTINO=C:\ExatasEmissor"
if not exist "%DESTINO%\app.py" (
  echo  [ERRO] Instalacao nao encontrada.
  pause & exit /b 1
)
echo  Desligando o emissor em %DESTINO%...
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*.exe' -and $_.CommandLine -like '*%DESTINO%*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
timeout /t 2 >nul
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"
timeout /t 2 >nul
powershell -NoProfile -Command "if (Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue) { exit 1 }"
if errorlevel 1 (echo  [AVISO] O sistema continua ligado e este usuario nao conseguiu desliga-lo. Feche esta janela e execute o atualizar.bat como ADMINISTRADOR ^(botao direito, Executar como administrador^). & pause & exit /b 1)
echo  Copia de seguranca da pasta dados (pode demorar alguns minutos, aguarde)...
for /f %%d in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmm"') do set DT=%%d
robocopy "%DESTINO%\dados" "%DESTINO%\backup\antes-1.42.1-%DT%" /E /XD backups_auto /NFL /NDL /NJH /NJS /NP >nul
del /q "%DESTINO%\cs_app.pyc" "%DESTINO%\integridade.json" "%DESTINO%\core\*.pyc" >nul 2>nul
copy /y "%~dp0app.py" "%DESTINO%\" >nul
copy /y "%~dp0cs_app.pyc" "%DESTINO%\" >nul
copy /y "%~dp0integridade.json" "%DESTINO%\" >nul
for %%p in (core templates static schemas) do robocopy "%~dp0%%p" "%DESTINO%\%%p" /E /NFL /NDL /NJH /NJS /NP >nul
attrib -r "%DESTINO%\core\*.py" >nul 2>nul
del /f /q "%DESTINO%\core\*.py" >nul 2>nul
copy /y "%~dp0atalhos.ps1" "%DESTINO%\" >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%DESTINO%\atalhos.ps1" -Pasta "%DESTINO%" -Renovar >nul 2>nul
if exist "%DESTINO%\core\__pycache__" rmdir /s /q "%DESTINO%\core\__pycache__"
if exist "%DESTINO%\__pycache__" rmdir /s /q "%DESTINO%\__pycache__"
if exist "%DESTINO%\static\app\sw.js" (echo  Atualizacao 1.42.1 aplicada: Troca de NFC-e: cancelamento no prazo ou devolucao.) else (echo  [ERRO] Os arquivos nao foram copiados. & pause & exit /b 1)
start "" wscript.exe "%DESTINO%\abrir.vbs"
timeout /t 5 >nul
