@echo off
chcp 65001 >nul
title Ativar Edicao Emissao Fiscal - Cavalcante Solucoes
set "DESTINO=C:\CavalcanteSolucoes"
if not exist "%DESTINO%\app.py" (
  echo  [ERRO] Instalacao nao encontrada.
  pause & exit /b 1
)
echo  Isto deixa o sistema SOMENTE com NF-e e NFS-e (sem PDV, estoque, financeiro, MDF-e, CT-e).
choice /c SN /m " Ativar a edicao Emissao Fiscal neste computador"
if errorlevel 2 exit /b 0
>"%DESTINO%\dados\edicao.txt" echo emissao
>"%DESTINO%\dados\modulos.txt" echo vendas,nfse
echo  Reiniciando o sistema...
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*.exe' -and $_.CommandLine -like '*%DESTINO%*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
timeout /t 2 >nul
start "" wscript.exe "%DESTINO%\abrir.vbs"
echo  Pronto. (Para voltar a edicao completa, apague dados\edicao.txt e reinicie.)
timeout /t 5 >nul
