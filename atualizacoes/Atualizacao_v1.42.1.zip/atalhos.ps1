﻿# Cria/renova os atalhos do Cavalcante Solucoes (nome e icone novos) e remove os dos nomes antigos.
param([string]$Pasta, [switch]$Desktop, [switch]$Inicializar, [switch]$Renovar)
$nome = "Cavalcante Solu" + [char]0x00E7 + [char]0x00F5 + "es"
$antigos = @("Cavalcante Solu" + [char]0x00E7 + [char]0x00F5 + "es - MDF-e.lnk", "Exatas Emissor MDF-e.lnk", "$nome.lnk")
$sh = New-Object -ComObject WScript.Shell
$dir = @{ D = [Environment]::GetFolderPath('Desktop'); S = [Environment]::GetFolderPath('Startup') }
$tinhaD = $false; $tinhaS = $false
foreach ($n in $antigos) {
  $a = Join-Path $dir.D $n; if (Test-Path $a) { $tinhaD = $true; Remove-Item $a -Force }
  $b = Join-Path $dir.S $n; if (Test-Path $b) { $tinhaS = $true; Remove-Item $b -Force }
}
if ($Renovar) { if ($tinhaD) { $Desktop = $true }; if ($tinhaS) { $Inicializar = $true } } elseif ($tinhaS) { $Inicializar = $true }
$icone = Join-Path $Pasta 'static\cavalcante.ico'
if (-not (Test-Path $icone)) { $icone = (Join-Path $Pasta 'python\pythonw.exe') + ',0' }
function Criar($destino, $script) {
  $s = $sh.CreateShortcut($destino)
  $s.TargetPath = 'wscript.exe'
  $s.Arguments = '"' + (Join-Path $Pasta $script) + '"'
  $s.WorkingDirectory = $Pasta
  $s.IconLocation = $icone
  $s.Description = $nome
  $s.Save()
}
if ($Desktop) { Criar (Join-Path $dir.D "$nome.lnk") 'abrir.vbs' }
if ($Inicializar) { Criar (Join-Path $dir.S "$nome.lnk") 'iniciar_servidor.vbs' }
