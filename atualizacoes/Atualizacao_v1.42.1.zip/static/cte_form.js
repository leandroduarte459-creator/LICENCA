/* Tela de emissão do CT-e - Cavalcante Soluções */
(() => {
  const ini = JSON.parse(document.getElementById('inicial').textContent);
  const E = ini.empresa, UFS = ini.ufs;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const dig = (v) => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const num = (v) => { const s = String(v ?? '').trim(); if (!s) return 0; return s.includes(',') ? parseFloat(s.replace(/\./g, '').replace(',', '.')) || 0 : parseFloat(s) || 0; };
  const dec = (v, c = 2) => (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: c, maximumFractionDigits: c });
  const brl = (v) => (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const fdoc = (d) => { d = dig(d); return d.length === 14 ? d.replace(/([A-Z0-9]{2})([A-Z0-9]{3})([A-Z0-9]{3})([A-Z0-9]{4})(\d{2})/, '$1.$2.$3/$4-$5') : d.length === 11 ? d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : d; };
  const cacheMun = {};
  const municipios = (uf) => (cacheMun[uf] = cacheMun[uf] || fetch('/api/municipios/' + uf).then((r) => r.json()));

  const st = {
    documentos: [], partes: { rem: null, dest: null, exped: null, receb: null }, toma4: null,
    aba: 'rem', inicio: null, fim: null, componentes: [], manualCarga: false, manualPeso: false,
  };

  /* ---------- seletor de município ---------- */
  function seletorMun(caixa, valor, onMuda) {
    const idl = 'dl' + Math.random().toString(36).slice(2);
    caixa.innerHTML = `<div class="linha"><select class="estreito">${UFS.map((u) => `<option>${u}</option>`).join('')}</select>
      <input list="${idl}" placeholder="Município"><datalist id="${idl}"></datalist></div>`;
    const sel = caixa.querySelector('select'), inp = caixa.querySelector('input'), dl = caixa.querySelector('datalist');
    let atual = { ...(valor || {}) };
    const carregar = async () => { const l = await municipios(sel.value); dl.innerHTML = l.map((m) => `<option value="${esc(m.nome)}">`).join(''); return l; };
    sel.value = atual.uf || E.uf; inp.value = atual.xmun || ''; carregar();
    sel.onchange = () => { inp.value = ''; atual = { uf: sel.value }; carregar(); onMuda && onMuda(atual); };
    inp.onchange = async () => {
      const l = await carregar();
      const m = l.find((x) => x.nome.toLowerCase() === inp.value.trim().toLowerCase());
      atual = m ? { uf: sel.value, cmun: m.codigo, xmun: m.nome } : { uf: sel.value };
      inp.setCustomValidity(m ? '' : 'Escolha um município da lista'); onMuda && onMuda(atual);
    };
    return { get: () => atual, set: (v) => { atual = { ...v }; sel.value = v.uf; inp.value = v.xmun || ''; carregar(); } };
  }
  const selIni = seletorMun($('sel-ini'), null, (v) => { st.inicio = v.cmun ? v : null; ajustarCfop(); });
  const selFim = seletorMun($('sel-fim'), null, (v) => { st.fim = v.cmun ? v : null; ajustarCfop(); });

  /* ---------- editor de participante ---------- */
  const CAMPOS = [['doc', 'CPF ou CNPJ', 2], ['ie', 'Inscrição estadual', 1], ['nome', 'Nome / razão social', 3],
    ['logradouro', 'Logradouro', 2], ['numero', 'Número', 1], ['bairro', 'Bairro', 1], ['complemento', 'Complemento', 1],
    ['cep', 'CEP', 1], ['fone', 'Telefone', 1], ['email', 'E-mail', 2]];
  const ROTULO = { rem: 'remetente', dest: 'destinatário', exped: 'expedidor', receb: 'recebedor', toma4: 'tomador' };

  function obterParte(p) { return p === 'toma4' ? st.toma4 : st.partes[p]; }
  function definirParte(p, v) { if (p === 'toma4') st.toma4 = v; else st.partes[p] = v; }

  function renderEditor() {
    const p = st.aba, d = obterParte(p) || {};
    const bloqueado = $('globalizado').checked && ((p === 'dest' && $('tomador').value === '0') || (p === 'rem' && $('tomador').value === '3'));
    document.querySelectorAll('#abas-part button').forEach((b) => b.classList.toggle('ativa', b.dataset.p === p));
    if (bloqueado) {
      $('editor-part').innerHTML = `<div class="flash aviso" style="margin:0">No CT-e Globalizado, o ${ROTULO[p]} sai com os dados da sua empresa
        (${esc(E.nome)}, ${fdoc(E.doc)})${Number(E.ambiente) === 1 ? ' e o nome "DIVERSOS", como exige a SEFAZ' : ''}. Não é preciso preencher.</div>`;
      return;
    }
    $('editor-part').innerHTML = `
      <div class="linha" style="margin-bottom:10px"><div style="flex:3"><label>Buscar no cadastro</label>
        <input id="busca-part" list="dl-part" placeholder="Digite nome ou CPF/CNPJ do ${ROTULO[p]}"><datalist id="dl-part"></datalist></div>
        ${['exped', 'receb', 'toma4'].includes(p) || d.doc ? `<div class="estreito"><button type="button" class="btn peq perigo" id="bt-limpar">Limpar</button></div>` : ''}</div>
      <div class="grade g4">${CAMPOS.map(([k, r, span]) => `<div class="campo" style="grid-column:span ${span}">
        <label for="p-${k}">${r}</label><input id="p-${k}" data-k="${k}" value="${esc(k === 'doc' ? fdoc(d[k]) : d[k])}"></div>`).join('')}
        <div class="campo" style="grid-column:span 2"><label>Município</label><div id="p-mun"></div></div></div>
      ${['exped', 'receb'].includes(p) ? '<p class="dica" style="margin:0">Opcional. Preencha só se houver expedidor ou recebedor diferente do remetente e do destinatário.</p>' : ''}`;
    const mun = seletorMun($('p-mun'), d.cmun ? { uf: d.uf, cmun: d.cmun, xmun: d.xmun } : { uf: d.uf || E.uf }, (v) => {
      const x = obterParte(p) || {}; definirParte(p, { ...x, cmun: v.cmun, xmun: v.xmun, uf: v.uf });
    });
    $('editor-part').querySelectorAll('input[data-k]').forEach((i) => i.addEventListener('input', () => {
      const x = obterParte(p) || {}; x[i.dataset.k] = i.dataset.k === 'doc' ? dig(i.value) : i.value; definirParte(p, x);
    }));
    const busca = $('busca-part'), dl = $('dl-part'); let achados = [];
    busca.addEventListener('input', async () => {
      if (busca.value.length < 2) return;
      achados = await (await fetch('/api/clientes?q=' + encodeURIComponent(busca.value))).json();
      dl.innerHTML = achados.map((c) => `<option value="${esc(c.nome)} - ${fdoc(c.doc)}">`).join('');
    });
    busca.addEventListener('change', () => {
      const c = achados.find((x) => `${x.nome} - ${fdoc(x.doc)}` === busca.value);
      if (c) { definirParte(p, { ...c, cmun: String(c.cmun) }); renderEditor(); conferir(); }
    });
    const lim = $('bt-limpar'); if (lim) lim.onclick = () => { definirParte(p, null); renderEditor(); };
    void mun;
  }
  document.querySelectorAll('#abas-part button').forEach((b) => (b.onclick = () => { st.aba = b.dataset.p; renderEditor(); }));

  /* ---------- importação de NF-e ---------- */
  const zona = $('soltar');
  ['dragenter', 'dragover'].forEach((ev) => zona.addEventListener(ev, (e) => { e.preventDefault(); zona.classList.add('sobre'); }));
  ['dragleave', 'drop'].forEach((ev) => zona.addEventListener(ev, (e) => { e.preventDefault(); zona.classList.remove('sobre'); }));
  zona.addEventListener('drop', (e) => importar(e.dataTransfer.files));
  $('arquivos').addEventListener('change', (e) => { importar(e.target.files); e.target.value = ''; });

  async function importar(arqs) {
    if (!arqs.length) return;
    const fd = new FormData(); [...arqs].forEach((a) => fd.append('arquivos', a));
    zona.querySelector('strong').textContent = 'Lendo notas…';
    try {
      const r = await (await fetch('/api/cte/importar', { method: 'POST', body: fd })).json();
      const avisos = [...r.erros];
      r.documentos.forEach((d) => {
        if (st.documentos.some((x) => x.chave === d.chave)) return avisos.push(`NF-e ${d.numero} já estava na lista.`);
        if (!d.autorizada) avisos.push(`NF-e ${d.numero}: o XML não tem protocolo de autorização.`);
        st.documentos.push(d);
        if (!st.partes.rem && d.emitente) st.partes.rem = d.emitente;
        if (!st.partes.dest && d.destinatario) st.partes.dest = d.destinatario;
        if (!st.inicio && d.carrega_cmun) { st.inicio = { uf: d.carrega_uf, cmun: +d.carrega_cmun, xmun: d.carrega_xmun }; selIni.set(st.inicio); }
        if (!st.fim && d.descarga_cmun) { st.fim = { uf: d.descarga_uf, cmun: +d.descarga_cmun, xmun: d.descarga_xmun }; selFim.set(st.fim); }
        if (!$('produto').value && d.produto) $('produto').value = d.produto.slice(0, 60);
        if (d.mod_frete === '0' && $('tomador').value === '0' && st.documentos.length === 1) $('tomador').value = '0';
        if (d.mod_frete === '1' && st.documentos.length === 1) $('tomador').value = '3';
      });
      if (avisos.length) alert(avisos.join('\n'));
    } catch (e) { alert('Não foi possível ler os arquivos: ' + e); }
    zona.querySelector('strong').textContent = 'Arraste os XMLs das NF-e aqui ou clique para escolher';
    ajustarCfop(); render(); renderEditor();
  }

  $('bt-ch-man').onclick = () => {
    const ch = dig($('ch-man').value);
    if (ch.length !== 44 || ch.substr(20, 2) !== '55') return alert('Informe a chave de 44 dígitos de uma NF-e (modelo 55).');
    if (st.documentos.some((x) => x.chave === ch)) return alert('Esta NF-e já está na lista.');
    st.documentos.push({ tipo: 'NFe', chave: ch, numero: String(+ch.substr(25, 9)), emit_nome: 'Informada pela chave', emit_doc: ch.substr(6, 14),
      valor: num($('ch-valor').value), peso: num($('ch-peso').value), volumes: 0, manual: true });
    $('ch-man').value = $('ch-valor').value = $('ch-peso').value = ''; render();
  };

  function render() {
    $('lista-docs').innerHTML = st.documentos.map((d, i) => `<li>
      <span class="tipo">NF-e</span>
      <span><b>${esc(d.numero)}</b>${d.serie ? '/' + esc(d.serie) : ''} <span class="dica">${esc(d.emit_nome || '')}</span><br>
        <span class="mono dica">${d.chave.replace(/(\d{4})(?=\d)/g, '$1 ')}</span></span>
      <span>${esc(d.descarga_xmun || '')}${d.descarga_uf ? '/' + esc(d.descarga_uf) : ''}<br><span class="dica">${brl(d.valor)}, ${dec(d.peso, 0)} kg</span></span>
      <button type="button" class="x" data-i="${i}" aria-label="Remover nota">×</button></li>`).join('');
    $('qtd-docs').textContent = st.documentos.length ? `${st.documentos.length} nota(s)` : '';
    const vc = st.documentos.reduce((s, d) => s + (+d.valor || 0), 0);
    const pe = st.documentos.reduce((s, d) => s + (+d.peso || 0), 0);
    const vo = st.documentos.reduce((s, d) => s + (+d.volumes || 0), 0);
    if (!st.manualCarga) $('vcarga').value = dec(vc);
    if (!st.manualPeso) { $('peso').value = dec(pe, 3); $('volumes').value = vo ? dec(vo, 0) : ''; }
    totais(); conferir();
  }
  $('lista-docs').onclick = (e) => { if (e.target.dataset.i !== undefined) { st.documentos.splice(+e.target.dataset.i, 1); render(); } };
  $('vcarga').oninput = () => { st.manualCarga = true; totais(); };
  $('peso').oninput = () => { st.manualPeso = true; };
  ['vprest', 'vrec'].forEach((id) => ($(id).oninput = () => { if (id === 'vprest' && !$('vrec').dataset.mexido) $('vrec').value = $('vprest').value; if (id === 'vrec') $('vrec').dataset.mexido = 1; totais(); }));

  function totais() {
    $('t-docs').textContent = st.documentos.length;
    $('t-carga').textContent = brl(num($('vcarga').value));
    $('t-frete').textContent = brl(num($('vprest').value));
  }

  /* ---------- componentes ---------- */
  function renderComps() {
    $('comps').innerHTML = st.componentes.map((c, i) => `<div class="linha" style="margin-bottom:6px">
      <div style="flex:2"><input data-i="${i}" data-k="nome" value="${esc(c.nome)}" maxlength="15" placeholder="Nome (ex.: FRETE PESO)"></div>
      <div><input data-i="${i}" data-k="valor" value="${c.valor ? dec(c.valor) : ''}" inputmode="decimal" placeholder="Valor"></div>
      <div class="estreito" style="flex-basis:40px"><button type="button" class="btn peq" data-del="${i}" aria-label="Remover componente">×</button></div></div>`).join('');
  }
  $('comps').oninput = (e) => { const i = e.target.dataset.i; if (i === undefined) return; st.componentes[i][e.target.dataset.k] = e.target.dataset.k === 'valor' ? num(e.target.value) : e.target.value; };
  $('comps').onclick = (e) => { if (e.target.dataset.del !== undefined) { st.componentes.splice(+e.target.dataset.del, 1); renderComps(); } };
  $('bt-comp').onclick = () => { st.componentes.push({ nome: st.componentes.length ? '' : 'FRETE PESO', valor: st.componentes.length ? 0 : num($('vprest').value) }); renderComps(); };

  /* ---------- CFOP / ICMS / globalizado ---------- */
  function ajustarCfop() {
    if (!st.inicio || !st.fim) return;
    const dentro = st.inicio.uf === st.fim.uf, c = $('cfop').value;
    const certo = (dentro ? '5' : '6') + c.slice(1);
    if (c[0] !== certo[0] && [...$('cfop').options].some((o) => o.value === certo)) $('cfop').value = certo;
    $('dica-cfop').textContent = dentro ? 'Prestação dentro do estado: CFOP 5xxx.' : 'Prestação entre estados: CFOP 6xxx.';
  }
  function dicaIcms() {
    const v = $('icms').value;
    $('aliq').disabled = !['00', '60', '90'].includes(v);
    $('dica-icms').textContent = v === 'SN' ? 'Simples Nacional: o ICMS é recolhido no DAS.' : '';
  }
  $('icms').onchange = dicaIcms;

  function conferir() {
    const remet = new Set(st.documentos.map((d) => d.emit_doc || d.chave.substr(6, 14)));
    const dests = new Set(st.documentos.map((d) => (d.destinatario || {}).doc).filter(Boolean));
    const glob = $('globalizado').checked;
    let aviso = '';
    if (!glob && (remet.size > 1 || dests.size > 1) && st.documentos.length > 1) {
      aviso = `<div class="flash aviso" style="margin:10px 0 0">As notas têm ${remet.size} remetente(s) e ${dests.size} destinatário(s).
        Um CT-e normal aceita só um remetente e um destinatário. Para juntar várias coletas ou entregas dentro do estado, marque <b>CT-e Globalizado</b>.</div>`;
    }
    $('aviso-glob').innerHTML = aviso;
    $('bloco-glob').hidden = !glob;
    if (glob) {
      const t = $('tomador').value, regras = [];
      if (t === '0') regras.push(`Tomador remetente: todas as NF-e do mesmo emitente (hoje: ${remet.size}) e pelo menos 5 notas (hoje: ${st.documentos.length}). O destinatário sai como a sua empresa.`);
      else if (t === '3') regras.push(`Tomador destinatário: NF-e de pelo menos 5 remetentes diferentes (hoje: ${remet.size}). O remetente sai como a sua empresa.`);
      else regras.push('No CT-e Globalizado, o tomador precisa ser o remetente ou o destinatário.');
      regras.push('Início e término da prestação no mesmo estado.');
      $('regras-glob').innerHTML = regras.join('<br>');
    }
  }
  $('globalizado').onchange = () => { conferir(); renderEditor(); };
  $('tomador').onchange = () => { $('aba-toma4').hidden = $('tomador').value !== '4'; if ($('tomador').value === '4') st.aba = 'toma4'; conferir(); renderEditor(); };

  /* ---------- montar e enviar ---------- */
  function coletar() {
    const q = [{ cunid: '01', tpmed: 'PESO BRUTO', qtd: num($('peso').value) }];
    if (num($('volumes').value) > 0) q.push({ cunid: '03', tpmed: 'VOLUMES', qtd: num($('volumes').value) });
    return {
      id: ini.id, cfop: $('cfop').value, tomador: $('tomador').value, globalizado: $('globalizado').checked,
      obs_glob: $('obs-glob').value.trim(), participantes: { ...st.partes }, toma4: $('tomador').value === '4' ? st.toma4 : null,
      inicio: st.inicio, fim: st.fim, retira: $('retira').checked,
      documentos: st.documentos, valor_prest: num($('vprest').value), valor_receber: num($('vrec').value || $('vprest').value),
      componentes: st.componentes.filter((c) => c.nome && c.valor > 0),
      icms_cst: $('icms').value, icms_aliq: num($('aliq').value),
      valor_carga: num($('vcarga').value), produto: $('produto').value.trim(), outras_carac: $('outras').value.trim(),
      quantidades: q, obs: $('obs').value.trim(), rntrc: E.rntrc, manual_carga: st.manualCarga, manual_peso: st.manualPeso,
    };
  }

  function faltas(d) {
    const f = [], glob = d.globalizado, t = d.tomador;
    const ok = (p) => p && dig(p.doc).length >= 11 && p.nome && p.cmun;
    if (!d.documentos.length) f.push('pelo menos uma NF-e');
    if (!(glob && t === '3') && !ok(d.participantes.rem)) f.push('remetente completo (CPF/CNPJ, nome e município)');
    if (!(glob && t === '0') && !ok(d.participantes.dest)) f.push('destinatário completo');
    if (t === '4' && !ok(d.toma4)) f.push('tomador (outros) completo');
    if ((t === '1' && !ok(d.participantes.exped)) || (t === '2' && !ok(d.participantes.receb))) f.push('dados do tomador escolhido');
    if (!d.inicio || !d.fim) f.push('início e término da prestação');
    if (d.valor_prest <= 0) f.push('valor da prestação');
    if (!d.produto) f.push('produto predominante');
    if (!E.rntrc) f.push('RNTRC da empresa (em Empresas)');
    const soma = d.componentes.reduce((s, c) => s + c.valor, 0);
    if (d.componentes.length && Math.abs(soma - d.valor_prest) > 0.009) f.push(`componentes somando ${brl(d.valor_prest)} (hoje ${brl(soma)})`);
    return f;
  }

  async function enviar(transmitir) {
    const d = coletar();
    if (transmitir) {
      const f = faltas(d);
      if (f.length) return alert('Para transmitir, falta: ' + f.join('; ') + '.');
      if (!confirm('Transmitir o CT-e para a SEFAZ agora?')) return;
    }
    d.transmitir = transmitir;
    [$('bt-salvar'), $('bt-emitir')].forEach((b) => (b.disabled = true));
    if (transmitir) $('bt-emitir').textContent = 'Transmitindo…';
    try {
      const r = await (await fetch('/ctes/salvar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d) })).json();
      if (r.erro) { alert(r.erro); if (r.id) ini.id = r.id; } else { location = r.url; return; }
    } catch (e) { alert('Falha de comunicação com o servidor: ' + e); }
    [$('bt-salvar'), $('bt-emitir')].forEach((b) => (b.disabled = false));
    $('bt-emitir').textContent = 'Salvar e transmitir';
  }
  $('bt-salvar').onclick = () => enviar(false);
  $('bt-emitir').onclick = () => enviar(true);

  /* ---------- estado inicial ---------- */
  $('cfop').value = E.cfop; $('icms').value = E.icms; $('aliq').value = E.aliq ? dec(E.aliq) : ''; $('obs-glob').value = E.obs_glob;
  if (ini.dados) {
    const d = ini.dados;
    st.documentos = d.documentos || []; st.partes = { rem: null, dest: null, exped: null, receb: null, ...(d.participantes || {}) };
    st.toma4 = d.toma4 || null; st.componentes = d.componentes || []; st.inicio = d.inicio; st.fim = d.fim;
    st.manualCarga = !!d.manual_carga; st.manualPeso = !!d.manual_peso;
    if (d.inicio) selIni.set(d.inicio); if (d.fim) selFim.set(d.fim);
    $('cfop').value = d.cfop || E.cfop; $('tomador').value = d.tomador || '0'; $('globalizado').checked = !!d.globalizado;
    $('obs-glob').value = d.obs_glob || E.obs_glob; $('retira').checked = !!d.retira;
    $('vprest').value = d.valor_prest ? dec(d.valor_prest) : ''; $('vrec').value = d.valor_receber ? dec(d.valor_receber) : '';
    $('icms').value = d.icms_cst || E.icms; $('aliq').value = d.icms_aliq ? dec(d.icms_aliq) : '';
    $('produto').value = d.produto || ''; $('outras').value = d.outras_carac || ''; $('obs').value = d.obs || '';
    $('vcarga').value = dec(d.valor_carga || 0);
    const q = d.quantidades || [];
    const p = q.find((x) => x.cunid === '01'), v = q.find((x) => x.cunid === '03');
    if (p) $('peso').value = dec(p.qtd, 3); if (v) $('volumes').value = dec(v.qtd, 0);
    $('aba-toma4').hidden = $('tomador').value !== '4';
  }
  dicaIcms(); renderComps(); render(); renderEditor();
})();
