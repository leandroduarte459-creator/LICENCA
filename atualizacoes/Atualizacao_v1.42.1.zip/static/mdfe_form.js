/* Tela de emissão do MDF-e */
(() => {
  const ini = JSON.parse(document.getElementById('inicial').textContent);
  const $ = (id) => document.getElementById(id);
  const UFS = ini.ufs;
  const cacheMun = {};

  const st = {
    documentos: [], carregamentos: [], percurso: [],
    valorManual: false, pesoManual: false,
  };

  // ---------- utilidades ----------
  const num = (v) => parseFloat(String(v || '').replace(/\./g, '').replace(',', '.')) || 0;
  const numPonto = (v) => { const s = String(v || '').trim(); return s.includes(',') ? num(s) : parseFloat(s) || 0; };
  const brl = (v) => (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const dec = (v, c = 2) => (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: c, maximumFractionDigits: c });
  const dig = (v) => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  async function municipios(uf) {
    if (!uf) return [];
    if (!cacheMun[uf]) cacheMun[uf] = fetch('/api/municipios/' + uf).then((r) => r.json());
    return cacheMun[uf];
  }

  /* Seletor de município: UF + nome com sugestões. onMuda({uf, cmun, xmun}) */
  function seletorMun(caixa, valor, onMuda) {
    const idl = 'dl' + Math.random().toString(36).slice(2);
    caixa.innerHTML = `<div class="linha"><select class="estreito">${UFS.map((u) => `<option>${u}</option>`).join('')}</select>
      <input list="${idl}" placeholder="Município"><datalist id="${idl}"></datalist></div>`;
    const sel = caixa.querySelector('select'), inp = caixa.querySelector('input'), dl = caixa.querySelector('datalist');
    let atual = { ...valor };
    sel.value = valor.uf || ini.empresa_uf;
    inp.value = valor.xmun || '';
    async function carregar() {
      const lista = await municipios(sel.value);
      dl.innerHTML = lista.map((m) => `<option value="${esc(m.nome)}">`).join('');
      return lista;
    }
    carregar();
    sel.addEventListener('change', () => { inp.value = ''; atual = { uf: sel.value }; carregar(); onMuda && onMuda(atual); });
    inp.addEventListener('change', async () => {
      const lista = await carregar();
      const alvo = inp.value.trim().toLowerCase();
      const m = lista.find((x) => x.nome.toLowerCase() === alvo);
      atual = m ? { uf: sel.value, cmun: m.codigo, xmun: m.nome } : { uf: sel.value };
      inp.setCustomValidity(m ? '' : 'Escolha um município da lista');
      inp.reportValidity();
      onMuda && onMuda(atual);
    });
    return {
      get: () => atual,
      set: (v) => { atual = { ...v }; sel.value = v.uf; inp.value = v.xmun || ''; carregar(); },
    };
  }

  // ---------- carregamento ----------
  const carrega = seletorMun($('carrega'), {}, (v) => { st.carregamentos = v.cmun ? [v] : []; });

  // ---------- descarregamento fixo ----------
  const descFixa = seletorMun($('desc-fixa'), {}, () => aplicarDescFixa());
  $('fixar-desc').addEventListener('change', (e) => { $('desc-fixa').hidden = !e.target.checked; aplicarDescFixa(); });
  function aplicarDescFixa() {
    const v = descFixa.get();
    st.documentos.forEach((d) => {
      if ($('fixar-desc').checked && v.cmun) { d.desc = { uf: v.uf, cmun: v.cmun, xmun: v.xmun }; }
      else { d.desc = { uf: d.descarga_uf, cmun: +d.descarga_cmun, xmun: d.descarga_xmun }; }
    });
    render();
  }

  // ---------- importação ----------
  const zona = $('soltar');
  ['dragenter', 'dragover'].forEach((ev) => zona.addEventListener(ev, (e) => { e.preventDefault(); zona.classList.add('sobre'); }));
  ['dragleave', 'drop'].forEach((ev) => zona.addEventListener(ev, (e) => { e.preventDefault(); zona.classList.remove('sobre'); }));
  zona.addEventListener('drop', (e) => importar(e.dataTransfer.files));
  $('arquivos').addEventListener('change', (e) => { importar(e.target.files); e.target.value = ''; });

  async function importar(arquivos) {
    if (!arquivos.length) return;
    const fd = new FormData();
    [...arquivos].forEach((a) => fd.append('arquivos', a));
    zona.querySelector('strong').textContent = 'Lendo arquivos…';
    try {
      const r = await (await fetch('/api/importar', { method: 'POST', body: fd })).json();
      const avisos = [...r.erros];
      r.documentos.forEach((d) => {
        if (st.documentos.some((x) => x.chave === d.chave)) { avisos.push(`Documento ${d.numero} já estava na lista.`); return; }
        if (!d.autorizada) avisos.push(`${d.tipo} ${d.numero}: o XML não tem protocolo de autorização. Confira se a nota foi autorizada.`);
        d.desc = { uf: d.descarga_uf, cmun: +d.descarga_cmun, xmun: d.descarga_xmun };
        st.documentos.push(d);
        sugerirDaNota(d, avisos);
      });
      if ($('fixar-desc').checked) aplicarDescFixa();
      if (avisos.length) alert(avisos.join('\n'));
    } catch (e) {
      alert('Não foi possível ler os arquivos: ' + e);
    }
    zona.querySelector('strong').textContent = 'Arraste os XMLs aqui ou clique para escolher';
    render();
  }

  function sugerirDaNota(d, avisos) {
    const c = { uf: d.carrega_uf, cmun: +d.carrega_cmun, xmun: d.carrega_xmun };
    if (!st.carregamentos.length) { st.carregamentos = [c]; carrega.set(c); }
    else if (st.carregamentos[0].uf !== c.uf) {
      avisos.push(`${d.tipo} ${d.numero} sai de ${c.uf}, diferente da UF de carregamento (${st.carregamentos[0].uf}). Cada UF de origem precisa de um MDF-e próprio.`);
    } else if (!st.carregamentos.some((x) => x.cmun === c.cmun)) {
      st.carregamentos.push(c);
    }
    if (d.transportador_cpf) {
      const cb = [...document.querySelectorAll('#motoristas input')].find((i) => i.dataset.cpf === dig(d.transportador_cpf));
      if (cb) cb.checked = true;
    }
    if (d.placa && !$('veiculo').value) {
      const op = [...$('veiculo').options].find((o) => o.dataset.placa === d.placa.toUpperCase().replace('-', ''));
      if (op) $('veiculo').value = op.value;
    }
    if (!st.percurso.length && ini.ufs_percurso) {
      st.percurso = ini.ufs_percurso.split(/[\s,;/]+/).filter((u) => UFS.includes(u));
    }
  }

  // chave manual
  const chMun = seletorMun($('ch-mun'), {}, null);
  $('bt-ch-man').addEventListener('click', () => {
    const ch = dig($('ch-man').value), m = chMun.get();
    if (ch.length !== 44) return alert('A chave de acesso precisa ter 44 dígitos.');
    if (!m.cmun) return alert('Escolha o município de descarregamento.');
    if (st.documentos.some((x) => x.chave === ch)) return alert('Este documento já está na lista.');
    const tipo = ch.substr(20, 2) === '57' ? 'CTe' : 'NFe';
    st.documentos.push({ tipo, chave: ch, numero: String(+ch.substr(25, 9)), emit_nome: 'Informado pela chave',
      valor: num($('ch-valor').value), peso: num($('ch-peso').value), desc: m, manual: true });
    $('ch-man').value = $('ch-valor').value = $('ch-peso').value = '';
    render();
  });

  // ---------- percurso ----------
  $('add-uf').addEventListener('change', (e) => {
    if (e.target.value) st.percurso.push(e.target.value);
    e.target.value = '';
    renderPercurso();
  });
  function renderPercurso() {
    $('percurso').innerHTML = st.percurso.map((u, i) => `<span class="chip">${u}<button type="button" data-i="${i}" aria-label="Remover ${u}">×</button></span>`).join('')
      || '<span class="dica">Nenhuma UF intermediária</span>';
  }
  $('percurso').addEventListener('click', (e) => {
    if (e.target.dataset.i !== undefined) { st.percurso.splice(+e.target.dataset.i, 1); renderPercurso(); }
  });

  // ---------- totais e lista ----------
  $('valor').addEventListener('input', () => { st.valorManual = true; totais(); });
  $('peso').addEventListener('input', () => { st.pesoManual = true; totais(); });

  function render() {
    $('lista-docs').innerHTML = st.documentos.map((d, i) => `<li>
      <span class="tipo">${d.tipo === 'CTe' ? 'CT-e' : 'NF-e'}</span>
      <span><b>${esc(d.numero)}</b>${d.serie ? '/' + esc(d.serie) : ''} <span class="dica">${esc(d.emit_nome || '')}</span><br>
        <span class="mono dica">${d.chave.replace(/(\d{4})(?=\d)/g, '$1 ')}</span></span>
      <span>${esc((d.desc || {}).xmun || '?')}/${esc((d.desc || {}).uf || '')}<br><span class="dica">${brl(d.valor)}, ${dec(d.peso, 0)} kg</span></span>
      <button type="button" class="x" data-i="${i}" aria-label="Remover documento">×</button></li>`).join('');
    $('qtd-docs').textContent = st.documentos.length ? `${st.documentos.length} importado(s)` : '';
    const ufsDesc = [...new Set(st.documentos.map((d) => (d.desc || {}).uf))];
    const munDesc = [...new Set(st.documentos.filter((d) => d.desc && d.desc.xmun).map((d) => `${d.desc.xmun}/${d.desc.uf}`))];
    $('resumo-desc').innerHTML = munDesc.length ? esc(munDesc.join(', ')) +
      (ufsDesc.length > 1 ? '<div class="flash erro" style="margin:6px 0 0">Os documentos descarregam em UFs diferentes. Um MDF-e só pode terminar em uma UF.</div>' : '')
      : 'Definido pelas notas importadas';
    renderPercurso();
    totais();
  }
  $('lista-docs').addEventListener('click', (e) => {
    if (e.target.dataset.i !== undefined) { st.documentos.splice(+e.target.dataset.i, 1); render(); }
  });

  function totais() {
    const v = st.documentos.reduce((s, d) => s + (+d.valor || 0), 0);
    const p = st.documentos.reduce((s, d) => s + (+d.peso || 0), 0);
    if (!st.valorManual) $('valor').value = dec(v);
    if (!st.pesoManual) $('peso').value = dec($('unid').value === '02' ? p / 1000 : p, 3);
    $('t-docs').textContent = st.documentos.length;
    $('t-valor').textContent = brl(num($('valor').value));
    $('t-peso').textContent = $('peso').value + ($('unid').value === '02' ? ' t' : ' kg');
  }
  $('unid').addEventListener('change', () => { st.pesoManual = false; totais(); });

  // ---------- montar e enviar ----------
  function coletar() {
    const grupos = {};
    st.documentos.forEach((d) => {
      const k = d.desc.cmun;
      grupos[k] = grupos[k] || { cmun: d.desc.cmun, xmun: d.desc.xmun, uf: d.desc.uf, docs: [] };
      grupos[k].docs.push({ tipo: d.tipo, chave: d.chave });
    });
    const descargas = Object.values(grupos);
    const marcados = (sel) => [...document.querySelectorAll(sel + ' input:checked')].map((i) => +i.value);
    return {
      id: ini.id,
      tp_emit: +$('tp-emit').value,
      uf_ini: st.carregamentos[0]?.uf || carrega.get().uf,
      uf_fim: descargas[0]?.uf || '',
      carregamentos: st.carregamentos,
      percurso: st.percurso,
      dh_ini_viagem: $('dh-ini').value || null,
      descargas, documentos: st.documentos,
      valor: num($('valor').value), peso: num($('peso').value), unid: $('unid').value,
      prod_pred: { tp_carga: $('pp-tipo').value, xprod: $('pp-xprod').value.trim(), ncm: dig($('pp-ncm').value) },
      veiculo_id: +$('veiculo').value || null,
      reboque_ids: marcados('#reboques'),
      motorista_ids: marcados('#motoristas'),
      contratantes: dig($('contr-doc').value) ? [{ doc: dig($('contr-doc').value), nome: $('contr-nome').value.trim() }] : [],
      rntrc: dig($('rntrc').value),
      seguro: { resp: $('sg-resp').value, resp_doc: dig($('sg-resp-doc').value), xseg: $('sg-xseg').value.trim(),
        cnpj_seg: dig($('sg-cnpj').value), apolice: $('sg-apol').value.trim(), averbacoes: $('sg-aver').value.trim() },
      inf_cpl: $('inf-cpl').value.trim(),
      carga_posterior: $('carga-post').checked,
      valor_manual: st.valorManual, peso_manual: st.pesoManual,
    };
  }

  function conferir(d) {
    const faltas = [];
    if (!d.carregamentos.length) faltas.push('o município de carregamento');
    if (!d.descargas.length) faltas.push('pelo menos uma NF-e ou CT-e');
    if (new Set(d.descargas.map((x) => x.uf)).size > 1) faltas.push('documentos que terminem numa única UF');
    if (!d.veiculo_id) faltas.push('o veículo de tração');
    if (!d.motorista_ids.length) faltas.push('pelo menos um motorista');
    if (d.reboque_ids.length > 3) faltas.push('no máximo 3 reboques');
    if (d.tp_emit === 1 && !(d.rntrc || ini.rntrc)) faltas.push('o RNTRC (obrigatório para transportadora)');
    if (d.tp_emit === 1) {
      const sg = d.seguro;
      if (!sg.cnpj_seg) faltas.push('o CNPJ da seguradora (seguro obrigatório para transportadora)');
      if (!sg.apolice) faltas.push('o número da apólice');
      if (!sg.averbacoes) faltas.push('o número da averbação do seguro');
      if (sg.resp === '2' && !sg.resp_doc) faltas.push('o CNPJ/CPF do contratante responsável pelo seguro');
    }
    if (d.valor <= 0 || d.peso <= 0) faltas.push('valor e peso da carga');
    return faltas;
  }

  async function enviar(transmitir) {
    const d = coletar();
    if (transmitir) {
      const faltas = conferir(d);
      if (faltas.length) return alert('Para transmitir, falta informar: ' + faltas.join(', ') + '.');
      if (!confirm('Transmitir o MDF-e para a SEFAZ agora?')) return;
    }
    d.transmitir = transmitir;
    const bts = [$('bt-salvar'), $('bt-emitir')];
    bts.forEach((b) => (b.disabled = true));
    $('bt-emitir').textContent = transmitir ? 'Transmitindo…' : $('bt-emitir').textContent;
    try {
      const resp = await fetch('/mdfes/salvar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d) });
      const r = await resp.json();
      if (r.erro) { alert(r.erro); if (r.id) ini.id = r.id; }
      else { location = r.url; return; }
    } catch (e) { alert('Falha de comunicação com o servidor: ' + e); }
    bts.forEach((b) => (b.disabled = false));
    $('bt-emitir').textContent = 'Salvar e transmitir';
  }
  $('bt-salvar').addEventListener('click', () => enviar(false));
  $('bt-emitir').addEventListener('click', () => enviar(true));

  // ---------- carregar dados existentes ----------
  $('tp-emit').value = String(ini.tp_emit || 2);
  const agora = new Date(); agora.setMinutes(agora.getMinutes() - agora.getTimezoneOffset());
  $('dh-ini').value = agora.toISOString().slice(0, 16);
  if (ini.dados) {
    const d = ini.dados;
    st.documentos = d.documentos || [];
    st.documentos.forEach((x) => {   // garante o local de descarregamento de cada documento
      if (x.desc && x.desc.xmun && x.desc.uf) return;
      const g = (d.descargas || []).find((q) => (q.docs || []).some((z) => z.chave === x.chave));
      if (g) x.desc = { uf: g.uf, cmun: g.cmun, xmun: g.xmun };
      else if (x.descarga_cmun) x.desc = { uf: x.descarga_uf, cmun: +x.descarga_cmun, xmun: x.descarga_xmun };
    });
    st.carregamentos = d.carregamentos || [];
    st.percurso = d.percurso || [];
    st.valorManual = !!d.valor_manual; st.pesoManual = !!d.peso_manual;
    if (st.carregamentos[0]) carrega.set(st.carregamentos[0]);
    $('tp-emit').value = String(d.tp_emit || 2);
    if (d.dh_ini_viagem) $('dh-ini').value = d.dh_ini_viagem;
    $('valor').value = dec(d.valor); $('unid').value = d.unid || '01'; $('peso').value = dec(d.peso, 3);
    if (d.prod_pred) { $('pp-tipo').value = d.prod_pred.tp_carga || '05'; $('pp-xprod').value = d.prod_pred.xprod || ''; $('pp-ncm').value = d.prod_pred.ncm || ''; }
    if (d.veiculo_id) $('veiculo').value = d.veiculo_id;
    (d.reboque_ids || []).forEach((i) => { const c = document.querySelector(`#reboques input[value="${i}"]`); if (c) c.checked = true; });
    (d.motorista_ids || []).forEach((i) => { const c = document.querySelector(`#motoristas input[value="${i}"]`); if (c) c.checked = true; });
    if (d.contratantes && d.contratantes[0]) { $('contr-doc').value = d.contratantes[0].doc; $('contr-nome').value = d.contratantes[0].nome || ''; }
    $('rntrc').value = d.rntrc || '';
    $('inf-cpl').value = d.inf_cpl || '';
    const sg = d.seguro || {};
    $('sg-resp').value = sg.resp || '1'; $('sg-resp-doc').value = sg.resp_doc || ''; $('sg-xseg').value = sg.xseg || '';
    $('sg-cnpj').value = sg.cnpj_seg || ''; $('sg-apol').value = sg.apolice || ''; $('sg-aver').value = sg.averbacoes || '';
    $('carga-post').checked = !!d.carga_posterior;
  }
  render();
})();
