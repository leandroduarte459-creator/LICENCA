/* Preenche o cadastro com os dados da Receita Federal ao digitar o CNPJ.
   Uso: <input data-cnpj="campoRazao"> — os outros campos são achados pelos ids padrão do formulário. */
(() => {
  const campoDoc = document.querySelector('[data-cnpj]');
  if (!campoDoc) return;
  const mapa = JSON.parse(campoDoc.dataset.cnpj);
  const aviso = document.createElement('div');
  aviso.className = 'dica';
  campoDoc.insertAdjacentElement('afterend', aviso);
  const bt = document.createElement('button');
  bt.type = 'button'; bt.className = 'btn peq'; bt.textContent = 'Buscar na Receita'; bt.style.marginTop = '6px';
  aviso.insertAdjacentElement('beforebegin', bt);
  const set = (id, v, forcar) => { const el = document.getElementById(id); if (el && v && (forcar || !el.value.trim() || el.dataset.auto)) { el.value = v; el.dataset.auto = '1'; } };
  let ultimo = '';
  async function buscar(forcar) {
    const doc = campoDoc.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (doc.length !== 14 || (doc === ultimo && !forcar)) return;
    ultimo = doc; aviso.textContent = 'Consultando a Receita Federal…'; bt.disabled = true;
    try {
      const r = await fetch('/api/cnpj/' + doc), d = await r.json();
      if (d.erro) { aviso.innerHTML = `<span style="color:var(--erro)">${d.erro}</span>`; return; }
      Object.entries(mapa).forEach(([k, id]) => set(id, d[k], forcar));
      const uf = document.getElementById('mun-uf'), nome = document.getElementById('mun-nome'), cod = document.getElementById('cmun');
      if (uf && d.uf) { uf.value = d.uf; uf.dispatchEvent(new Event('change')); }
      if (nome && d.xmun) { setTimeout(() => { nome.value = d.xmun; cod.value = d.cmun; nome.setCustomValidity(''); }, 50); }
      const crt = document.getElementById('crt'); if (crt && d.crt) crt.value = String(d.crt);
      const sit = d.situacao && d.situacao.toUpperCase() !== 'ATIVA' ? ` <b style="color:var(--erro)">Situação: ${d.situacao}</b>` : '';
      aviso.innerHTML = `Dados da Receita preenchidos (${d.fonte}).${d.simples ? ' Optante pelo Simples Nacional.' : ''}${d.mei ? ' MEI.' : ''}${d.ie ? '' : ' Inscrição estadual não encontrada: confira no SINTEGRA.'}${sit}`;
    } catch (e) { aviso.textContent = 'Não foi possível consultar agora.'; }
    finally { bt.disabled = false; }
  }
  campoDoc.addEventListener('blur', () => buscar(false));
  campoDoc.addEventListener('input', () => { if (campoDoc.value.toUpperCase().replace(/[^A-Z0-9]/g, '').length === 14) buscar(false); });
  bt.addEventListener('click', () => { ultimo = ''; buscar(true); });
})();
