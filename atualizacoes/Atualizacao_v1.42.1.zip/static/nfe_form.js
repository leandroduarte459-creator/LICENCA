/* Emissão de NF-e / NFC-e - pensada para quem não conhece nota fiscal */
(() => {
  const ini = JSON.parse(document.getElementById('inicial').textContent);
  const $ = (id) => document.getElementById(id);
  const d0 = ini.dados || {};
  const st = { itens: d0.itens || [], pag: d0.pag || [], dest: d0.dest || null };
  const num = (v) => { const s = String(v ?? '').trim(); return s.includes(',') ? parseFloat(s.replace(/\./g, '').replace(',', '.')) || 0 : parseFloat(s) || 0; };
  const brl = (v) => (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const dec = (v, c = 2) => (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: c, maximumFractionDigits: c });
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const dig = (v) => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const nat = () => ($('natureza') ? $('natureza').value : 'venda');
  const totais = () => {
    let p = 0, dsc = 0;
    st.itens.forEach((i) => { p += i.qtd * i.vun; dsc += num(i.vdesc); });
    return { prod: p, desc: dsc, total: Math.round((p - dsc + num($('vfrete')?.value)) * 100) / 100 };
  };

  // ---------- produtos ----------
  let sugest = [], idx = -1, timer;
  const busca = $('busca'), ul = $('sugestoes');
  async function buscar(q) {
    if (q.length < 2 && !/^\d+$/.test(q)) { ul.innerHTML = ''; sugest = []; return; }
    sugest = await (await fetch('/api/produtos?q=' + encodeURIComponent(q))).json();
    idx = sugest.length ? 0 : -1;
    ul.innerHTML = sugest.map((p, i) => `<li data-i="${i}" style="grid-template-columns:1fr auto;cursor:pointer;${i === 0 ? 'background:var(--placa-clara)' : ''}"><span><b>${esc(p.descricao)}</b> <span class="dica">${esc(p.codigo)} ${p.ean ? '· ' + p.ean : ''}${p.controla_estoque ? ' · estoque ' + dec(p.estoque, 0) : ''}</span></span><b>${brl(p.preco)}</b></li>`).join('');
  }
  function parse() {
    const m = busca.value.match(/^\s*(\d+(?:[.,]\d+)?)\s*\*\s*(.+)$/);
    return m ? { qtd: num(m[1]), q: m[2].trim() } : { qtd: num($('qtd-add').value) || 1, q: busca.value.trim() };
  }
  busca.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => buscar(parse().q), 180); });
  busca.addEventListener('keydown', async (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); idx = Math.max(0, Math.min(sugest.length - 1, idx + (e.key === 'ArrowDown' ? 1 : -1))); [...ul.children].forEach((li, i) => li.style.background = i === idx ? 'var(--placa-clara)' : ''); }
    if (e.key === 'Enter') { e.preventDefault(); await confirmar(); }
    if (e.key === 'Escape') { ul.innerHTML = ''; }
  });
  async function confirmar() {
    const { qtd, q } = parse();
    if (!q) return;
    if (!sugest.length || ul.innerHTML === '') await buscar(q);
    const exato = sugest.find((p) => p.ean === dig(q) || p.codigo === q);
    const p = exato || sugest[idx];
    if (p) adicionar(p, qtd); else alert('Produto não encontrado: ' + q);
  }
  ['qtd-add', 'vun-add', 'desc-add'].forEach((id) => $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); confirmar(); } }));
  ul.addEventListener('click', (e) => { const li = e.target.closest('li'); if (li) adicionar(sugest[+li.dataset.i], parse().qtd); });
  function adicionar(p, qtd) {
    const vAdd = num($('vun-add').value), dAdd = num($('desc-add').value);
    const preco = vAdd > 0 ? vAdd : p.preco;
    const ex = dAdd > 0 ? null : st.itens.find((i) => i.produto_id === p.id && i.vun === preco && !num(i.vdesc));
    if (ex) ex.qtd += qtd;
    else st.itens.unshift({ produto_id: p.id, codigo: p.codigo, ean: p.ean, descricao: p.descricao, ncm: p.ncm, cest: p.cest, unidade: p.unidade, origem: p.origem, perfil: p.perfil, qtd, vun: preco, vdesc: dAdd > 0 ? dAdd : 0, cst_icms: p.cst_icms || '', aliq_icms: p.aliq_icms || 0, red_bc: p.red_bc || 0, mva: p.mva || 0, aliq_st: p.aliq_st || 0, red_bc_st: p.red_bc_st || 0, fcp: p.fcp || 0, cst_pis: p.cst_pis || '', aliq_pis: p.aliq_pis || 0, aliq_cofins: p.aliq_cofins || 0, cst_ipi: p.cst_ipi || '', aliq_ipi: p.aliq_ipi || 0, aliq_inter: p.aliq_inter || 0, red_bc_inter: (p.red_bc_inter === undefined ? null : p.red_bc_inter), alerta: (!p.ncm || p.ncm.length !== 8) ? 'Sem NCM' : (p.perfil === 'st' && (p.cest || '').length !== 7 ? 'ST sem CEST' : '') });
    if (cfopTodos && cfopTodos.value) st.itens.forEach((it) => { if (!it.cfop_manual) it.cfop_manual = cfopTodos.value; });
    if (tribTodos && tribTodos.value) st.itens.forEach((it) => { if (!it.trib_manual) it.trib_manual = tribTodos.value; });
    busca.value = ''; $('qtd-add').value = '1'; $('vun-add').value = ''; $('desc-add').value = ''; ul.innerHTML = ''; sugest = [];
    render();
    const ki = ex ? st.itens.indexOf(ex) : 0, qi = document.querySelector(`#itens input[data-i="${ki}"][data-k="qtd"]`);
    if (qi) { qi.focus(); qi.select(); } else busca.focus();
  }
  $('itens').addEventListener('keydown', (e) => {   // Enter na quantidade/valor/desconto volta para a busca do próximo produto
    if (e.key === 'Enter' && e.target.dataset && ['qtd', 'vun', 'vdesc'].includes(e.target.dataset.k)) { e.preventDefault(); busca.focus(); }
  });
  $('itens').addEventListener('focusin', (e) => { if (e.target.dataset && ['qtd', 'vun', 'vdesc'].includes(e.target.dataset.k)) e.target.select(); });
  $('itens').addEventListener('input', (e) => {
    const i = +e.target.dataset.i, k = e.target.dataset.k;
    if (k === 'trib_manual') { e.target.value = e.target.value.replace(/\D/g, '').slice(0, 3); st.itens[i][k] = e.target.value; }
    else if (k === 'cfop_manual') { e.target.value = e.target.value.replace(/\D/g, '').slice(0, 4); st.itens[i][k] = e.target.value; }
    else if (k) { st.itens[i][k] = k === 'vdesc' ? e.target.value : num(e.target.value); atualizar(); }
  });
  $('itens').addEventListener('click', (e) => {
    if (e.target.dataset.x !== undefined) { st.itens.splice(+e.target.dataset.x, 1); render(); }
    else if (e.target.dataset.ed !== undefined) abrirEdicao(+e.target.dataset.ed);
  });
  const cfopTodos = $('cfop-todos');
  if (cfopTodos) {
    const c0 = (d0.itens || []).map((i) => i.cfop_manual || '');
    if (c0.length && c0.every((c) => c === c0[0])) cfopTodos.value = c0[0];
    cfopTodos.addEventListener('input', () => { cfopTodos.value = cfopTodos.value.replace(/\D/g, '').slice(0, 4); st.itens.forEach((it) => { it.cfop_manual = cfopTodos.value; }); render(); });
  }
  const tribTodos = $('trib-todos');
  if (tribTodos) {
    const t0 = (d0.itens || []).map((i) => i.trib_manual || '');
    if (t0.length && t0.every((c) => c === t0[0])) tribTodos.value = t0[0];
    tribTodos.addEventListener('input', () => { tribTodos.value = tribTodos.value.replace(/\D/g, '').slice(0, 3); st.itens.forEach((it) => { it.trib_manual = tribTodos.value; }); render(); });
  }
  // ---------- janela de edição do item (vale só para esta nota) ----------
  const CAMPOS_TRIB = ['cst_icms', 'aliq_icms', 'red_bc', 'aliq_inter', 'red_bc_inter', 'mva', 'aliq_st', 'red_bc_st', 'fcp', 'cst_pis', 'aliq_pis', 'aliq_cofins', 'cst_ipi', 'aliq_ipi'];
  function abrirEdicao(i) {
    const it = st.itens[i], normal = ini.crt === 3;
    const f = (k, rot, ex = '', v = it[k], span = '') => `<label class="me-c" style="${span}"><span>${rot}</span><input id="me-${k}" value="${esc(v == null ? '' : v)}" ${ex}></label>`;
    const sel = (k, rot, ops, v = it[k]) => `<label class="me-c"><span>${rot}</span><select id="me-${k}">${ops.map(([o, t]) => `<option value="${o}" ${String(v == null ? '' : v) === o ? 'selected' : ''}>${t}</option>`).join('')}</select></label>`;
    const cstOps = [['', 'Cadastro/matriz'], ['00', '00 Tributada'], ['10', '10 Trib. com ST'], ['20', '20 Redução de base'], ['30', '30 Isenta com ST'], ['40', '40 Isenta'], ['41', '41 Não tributada'], ['50', '50 Suspensão'], ['60', '60 ST anterior'], ['70', '70 Redução com ST'], ['90', '90 Outras']];
    const csosnOps = [['', 'Automático'], ['101', '101 Com crédito'], ['102', '102 Sem crédito'], ['103', '103 Isento (faixa)'], ['300', '300 Imune'], ['400', '400 Não tributada'], ['500', '500 ST anterior'], ['900', '900 Outros']];
    const sec = (t) => `<div class="me-t">${t}</div>`;
    const ov = document.createElement('div');
    ov.id = 'modal-item';
    ov.innerHTML = `<style>
      #modal-item{position:fixed;inset:0;background:rgba(15,25,20,.55);z-index:1000;display:flex;align-items:flex-start;justify-content:center;padding:3vh 12px;overflow:auto}
      #modal-item .me-box{background:var(--papel,#fff);color:inherit;width:min(860px,100%);border-radius:14px;box-shadow:0 20px 60px rgba(0,0,0,.35);display:flex;flex-direction:column;max-height:94vh}
      #modal-item .me-cab{padding:14px 18px;border-bottom:1px solid rgba(0,0,0,.12);display:flex;justify-content:space-between;align-items:center;gap:10px}
      #modal-item .me-corpo{padding:10px 18px 16px;overflow:auto}
      #modal-item .me-rod{padding:12px 18px;border-top:1px solid rgba(0,0,0,.12);display:flex;justify-content:flex-end;gap:10px;background:rgba(0,0,0,.03);border-radius:0 0 14px 14px}
      #modal-item .me-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px}
      #modal-item .me-c{display:flex;flex-direction:column;gap:3px;font-size:.82rem;font-weight:600}
      #modal-item .me-c input,#modal-item .me-c select,#modal-item .me-c textarea{width:100%;font-weight:400}
      #modal-item .me-t{font-weight:800;margin:14px 0 6px;font-size:.9rem;text-transform:uppercase;letter-spacing:.03em;opacity:.75}
    </style><div class="me-box" role="dialog" aria-modal="true">
      <div class="me-cab"><div><b style="font-size:1.1rem">Editar item ${i + 1}</b><div class="dica">Vale só para esta nota. O cadastro do produto não muda.</div></div><button type="button" class="btn peq" id="me-x">Cancelar</button></div>
      <div class="me-corpo">
        ${sec('Produto')}<div class="me-g">${f('descricao', 'Descrição', 'maxlength="120"', it.descricao, 'grid-column:1/-1')}
          ${f('codigo', 'Código', 'maxlength="60"')}${f('ean', 'Código de barras (EAN)', 'inputmode="numeric" maxlength="14"')}${f('ncm', 'NCM (8 dígitos)', 'inputmode="numeric" maxlength="8"')}${f('cest', 'CEST (7 dígitos)', 'inputmode="numeric" maxlength="7"')}${f('unidade', 'Unidade', 'maxlength="6"')}
          ${sel('origem', 'Origem', [['0', '0 Nacional'], ['1', '1 Estrangeira, import. direta'], ['2', '2 Estrangeira, mercado interno'], ['3', '3 Nacional, import. >40%'], ['4', '4 Nacional, proc. básicos'], ['5', '5 Nacional, import. ≤40%'], ['6', '6 Estrangeira, sem similar'], ['7', '7 Estrangeira, sem similar (interno)'], ['8', '8 Nacional, import. >70%']], String(it.origem == null ? '0' : it.origem))}
          ${sel('perfil', 'Perfil do item', [['normal', 'Normal'], ['st', 'Substituição tributária'], ['isento', 'Isento / não tributado']], it.perfil || 'normal')}</div>
        ${sec('Valores')}<div class="me-g">${f('qtd', 'Quantidade', 'inputmode="decimal"', dec(it.qtd, 3).replace(/,?0+$/, ''))}${f('vun', 'Valor unitário', 'inputmode="decimal"', dec(it.vun))}${f('vdesc', 'Desconto (R$)', 'inputmode="decimal" placeholder="0,00"', it.vdesc ? dec(num(it.vdesc)) : '')}</div>
        ${sec('Operação e tributação')}<div class="me-g">${f('cfop_manual', 'CFOP (vazio = automático)', 'inputmode="numeric" maxlength="4" placeholder="auto"')}
          ${normal ? sel('cst_icms', 'CST do ICMS', cstOps) + f('aliq_icms', 'Alíquota ICMS %', 'inputmode="decimal"') + f('red_bc', 'Redução da base %', 'inputmode="decimal"') + f('aliq_inter', 'Alíq. interestadual % (4/7/12)', 'inputmode="decimal" placeholder="automática"') + f('red_bc_inter', 'Red. base interestadual %', 'inputmode="decimal" placeholder="igual à interna"') + f('fcp', 'FCP %', 'inputmode="decimal"') + f('mva', 'MVA / IVA-ST %', 'inputmode="decimal"') + f('aliq_st', 'Alíquota ICMS-ST %', 'inputmode="decimal"') + f('red_bc_st', 'Red. base ST %', 'inputmode="decimal"') + f('cst_pis', 'CST PIS/COFINS', 'maxlength="2" placeholder="01"') + f('aliq_pis', 'Alíquota PIS %', 'inputmode="decimal"') + f('aliq_cofins', 'Alíquota COFINS %', 'inputmode="decimal"') + f('cst_ipi', 'CST IPI', 'maxlength="2" placeholder="vazio = sem IPI"') + f('aliq_ipi', 'Alíquota IPI %', 'inputmode="decimal"')
                    : sel('trib_manual', 'CSOSN (Simples Nacional)', csosnOps, it.trib_manual || '')}</div>
        ${normal ? '<div class="dica" style="margin-top:6px">Se alterar qualquer dado de tributação, a nota usa o que está aqui no lugar do cadastro/matriz do produto.</div>' : ''}
        ${sec('Informações do item')}<div class="me-g">${f('xped', 'Nº do pedido do cliente (xPed)', 'maxlength="15"')}${f('nitemped', 'Item do pedido (nº)', 'inputmode="numeric" maxlength="6"')}
          <label class="me-c" style="grid-column:1/-1"><span>Informação adicional do item (sai na nota)</span><textarea id="me-inf_ad" rows="3" maxlength="500">${esc(it.inf_ad || '')}</textarea></label></div>
      </div>
      <div class="me-rod"><button type="button" class="btn" id="me-cancel">Cancelar</button><button type="button" class="btn prim" id="me-ok">Salvar item</button></div></div>`;
    document.body.appendChild(ov);
    const V = (k) => ov.querySelector('#me-' + k);
    const fechar = () => { ov.remove(); document.removeEventListener('keydown', esc_); };
    const esc_ = (ev) => { if (ev.key === 'Escape') fechar(); };
    document.addEventListener('keydown', esc_);
    ['ncm', 'cest', 'ean', 'nitemped', 'cst_pis', 'cst_ipi', 'cfop_manual'].forEach((k) => { const el = V(k); if (el) el.addEventListener('input', () => { el.value = el.value.replace(/\D/g, ''); }); });
    if (V('unidade')) V('unidade').addEventListener('input', (ev) => { ev.target.value = ev.target.value.toUpperCase(); });
    ov.querySelector('#me-x').onclick = ov.querySelector('#me-cancel').onclick = fechar;
    ov.querySelector('#me-ok').onclick = () => {
      const g = (k) => (V(k) ? V(k).value.trim() : '');
      if (!g('descricao')) return alert('Informe a descrição do produto.');
      if (g('ncm') && g('ncm').length !== 8) return alert('O NCM deve ter 8 dígitos.');
      if (g('cest') && g('cest').length !== 7) return alert('O CEST deve ter 7 dígitos.');
      if (g('cfop_manual') && g('cfop_manual').length !== 4) return alert('O CFOP deve ter 4 dígitos.');
      if (!(num(g('qtd')) > 0)) return alert('A quantidade deve ser maior que zero.');
      if (normal) {
        const ai = num(g('aliq_inter'));
        if (![0, 4, 7, 12].includes(ai)) return alert('A alíquota interestadual deve ser 4, 7 ou 12 (ou vazia = automática).');
        const c = g('cst_icms');
        if (['20', '70'].includes(c) && !(num(g('red_bc')) > 0) && g('red_bc_inter') === '') return alert('CST ' + c + ' exige o percentual de redução da base.');
      }
      ['descricao', 'codigo', 'ean', 'ncm', 'cest', 'unidade', 'xped', 'nitemped'].forEach((k) => { it[k] = g(k); });
      it.inf_ad = V('inf_ad').value.trim();
      it.origem = g('origem'); it.perfil = g('perfil');
      it.qtd = num(g('qtd')); it.vun = num(g('vun')); it.vdesc = g('vdesc');
      it.cfop_manual = g('cfop_manual');
      if (normal) {
        let mudou = false;
        CAMPOS_TRIB.forEach((k) => {
          const novo = ['aliq_icms', 'red_bc', 'aliq_inter', 'mva', 'aliq_st', 'red_bc_st', 'fcp', 'aliq_pis', 'aliq_cofins', 'aliq_ipi'].includes(k) ? num(g(k)) : k === 'red_bc_inter' ? (g(k) === '' ? null : num(g(k))) : g(k);
          if (String(it[k] ?? '') !== String(novo ?? '')) mudou = true;
          it[k] = novo;
        });
        if (mudou) { it.trib_editada = true; it.trib_manual = ''; }
      } else { it.trib_manual = g('trib_manual'); }
      it.alerta = (!it.ncm || it.ncm.length !== 8) ? 'Sem NCM' : (it.perfil === 'st' && (it.cest || '').length !== 7 ? 'ST sem CEST' : '');
      fechar(); render();
    };
    V('descricao').focus();
  }
  function render() {
    $('itens').innerHTML = st.itens.map((it, i) => `<tr><td>${i + 1}</td><td><b id="nm${i}">${esc(it.descricao)}</b><div class="dica">${esc(it.codigo)} · ${{ normal: 'Normal', st: 'ST', isento: 'Isento' }[it.perfil] || ''}${it.alerta ? ' · <span class="st st-rejeitado">' + it.alerta + '</span>' : ''}</div></td>
      <td><input data-i="${i}" data-k="qtd" value="${dec(it.qtd, 3).replace(/,?0+$/, '')}" inputmode="decimal"></td>
      <td><input data-i="${i}" data-k="vun" value="${dec(it.vun)}" inputmode="decimal"></td>
      <td><input data-i="${i}" data-k="vdesc" value="${it.vdesc ? dec(num(it.vdesc)) : ''}" inputmode="decimal" placeholder="0,00"></td>
      <td style="text-align:right" id="tl${i}">${brl(it.qtd * it.vun - num(it.vdesc))}</td><td style="white-space:nowrap"><button type="button" class="btn peq" data-ed="${i}" title="Editar todos os dados deste item (vale só para esta nota)">Editar</button> <button type="button" class="btn peq perigo" data-x="${i}" aria-label="Remover">×</button></td></tr>${ini.modelo === 55 ? `<tr class="sub"><td></td><td colspan="6" style="padding-top:0"><span class="dica" style="display:inline-flex;gap:14px;flex-wrap:wrap;align-items:center">Preenchimento manual (vazio = automático): <label style="display:inline-flex;gap:6px;align-items:center;font-weight:600">CFOP <input data-i="${i}" data-k="cfop_manual" value="${esc(it.cfop_manual || '')}" inputmode="numeric" maxlength="4" placeholder="auto" style="width:80px"></label><label style="display:inline-flex;gap:6px;align-items:center;font-weight:600">CSOSN/CST <input data-i="${i}" data-k="trib_manual" value="${esc(it.trib_manual || '')}" inputmode="numeric" maxlength="3" placeholder="auto" style="width:80px"></label></span></td></tr>` : ''}`).join('');
    $('vazio').hidden = st.itens.length > 0;
    atualizar();
  }
  function atualizar() {
    st.itens.forEach((it, i) => { const c = $('tl' + i); if (c) c.textContent = brl(it.qtd * it.vun - num(it.vdesc)); });
    const t = totais();
    $('t-prod').textContent = brl(t.prod); $('t-desc').textContent = brl(t.desc);
    $('t-total').textContent = $('t-total2').textContent = brl(t.total); $('t-itens').textContent = st.itens.length;
    if (st.pag.length === 1 && !st.pag[0].manual) st.pag[0].valor = t.total;
    renderPag();
  }

  // ---------- pagamento ----------
  const comPag = () => !!(ini.naturezas[nat()] || {}).pag;
  $('formas').addEventListener('click', (e) => {
    const tp = e.target.dataset.tpag; if (!tp) return;
    const t = totais().total, pago = st.pag.reduce((s, p) => s + num(p.valor), 0);
    st.pag.push({ tpag: tp, valor: Math.max(0, Math.round((t - pago) * 100) / 100) || t });
    if (st.pag.length > 1) st.pag.forEach((p) => p.manual = true);
    renderPag();
  });
  $('pags').addEventListener('input', (e) => { const i = +e.target.dataset.i; st.pag[i].valor = num(e.target.value); st.pag[i].manual = true; troco(); });
  $('pags').addEventListener('click', (e) => { if (e.target.dataset.x !== undefined) { st.pag.splice(+e.target.dataset.x, 1); renderPag(); } });
  function renderPag() {
    $('bloco-pag').hidden = !comPag();
    $('pags').innerHTML = st.pag.map((p, i) => `<li style="grid-template-columns:1fr 140px auto"><b>${esc(ini.tpag[p.tpag] || p.tpag)}</b><input data-i="${i}" value="${dec(num(p.valor))}" inputmode="decimal"><button type="button" class="x" data-x="${i}" aria-label="Remover">×</button></li>`).join('');
    troco();
  }
  function troco() {
    const t = totais().total, pago = st.pag.reduce((s, p) => s + num(p.valor), 0);
    $('troco').innerHTML = !st.pag.length ? 'Escolha a forma de pagamento.' : pago > t + 0.001 ? `Troco: <b>${brl(pago - t)}</b>` : pago + 0.001 < t ? `<span style="color:var(--erro)">Faltam ${brl(t - pago)}</span>` : '';
  }

  // ---------- cliente ----------
  const bc = $('busca-cli'), sc = $('sug-cli');
  let clientes = [];
  bc.addEventListener('input', async () => {
    const q = bc.value.trim();
    if (ini.modelo === 65) { st.dest = dig(q).length === 11 || dig(q).length === 14 ? { doc: dig(q) } : null; mostrarCli(); }
    if (q.length < 3) { sc.innerHTML = ''; return; }
    clientes = await (await fetch('/api/clientes?q=' + encodeURIComponent(q))).json();
    sc.innerHTML = clientes.map((c, i) => `<li data-i="${i}" style="grid-template-columns:1fr;cursor:pointer"><span><b>${esc(c.nome)}</b> <span class="dica">${esc(c.doc)} · ${esc(c.xmun)}/${esc(c.uf)}</span></span></li>`).join('');
  });
  sc.addEventListener('click', (e) => { const li = e.target.closest('li'); if (!li) return; usarCli(clientes[+li.dataset.i]); });
  function usarCli(c) { st.dest = c; sc.innerHTML = ''; bc.value = ''; mostrarCli(); preencherCli(c); }
  function mostrarCli() {
    const c = st.dest;
    $('cli-sel').innerHTML = c && c.doc ? `<b>${esc(c.nome || (dig(c.doc).length === 11 ? 'CPF' : 'CNPJ'))}</b> · ${esc(c.doc)}${c.xmun ? ' · ' + esc(c.xmun) + '/' + esc(c.uf) : ''}${c.ie ? ' · IE ' + esc(c.ie) : ''} <a href="#" id="limpa-cli">remover</a>` : (ini.modelo === 65 ? 'Consumidor não identificado' : 'Nenhum cliente escolhido');
    const l = $('limpa-cli'); if (l) l.onclick = (e) => { e.preventDefault(); st.dest = null; mostrarCli(); };
  }
  const CAMPOS = ['doc', 'ie', 'nome', 'logradouro', 'numero', 'bairro', 'cep', 'fone', 'email', 'xmun'];
  function preencherCli(c) { if (!$('c-doc')) return; CAMPOS.forEach((k) => $('c-' + k).value = c[k] || ''); $('c-uf').value = c.uf || ini.uf; carregarMun(); }
  async function carregarMun() { if (!$('c-uf')) return []; const l = await (await fetch('/api/municipios/' + $('c-uf').value)).json(); $('dl-mun').innerHTML = l.map((m) => `<option value="${esc(m.nome)}">`).join(''); return l; }
  if ($('c-uf')) { $('c-uf').onchange = carregarMun; carregarMun(); }
  if ($('bt-cli')) $('bt-cli').onclick = async () => {
    const c = {}; CAMPOS.forEach((k) => c[k] = $('c-' + k).value.trim()); c.uf = $('c-uf').value; c.doc = dig(c.doc);
    const m = (await carregarMun()).find((x) => x.nome.toLowerCase() === c.xmun.toLowerCase());
    if (![11, 14].includes(c.doc.length) || !c.nome || !m) return alert('Informe CPF/CNPJ, nome e escolha o município da lista.');
    c.cmun = m.codigo; c.xmun = m.nome; st.dest = c; mostrarCli(); $('cli-novo').open = false;
  };

  // ---------- operação ----------
  function ajustarNat() {
    const n = ini.naturezas[nat()] || {};
    if ($('bloco-ref')) $('bloco-ref').hidden = !n.ref;
    if (comPag() && !st.pag.length) st.pag.push({ tpag: '01', valor: totais().total });
    renderPag();
  }
  if ($('natureza')) $('natureza').onchange = ajustarNat;
  if ($('vfrete')) $('vfrete').oninput = atualizar;

  // ---------- enviar ----------
  function coletar() {
    return {
      id: ini.id, modelo: ini.modelo, natureza: nat(), itens: st.itens.map((i) => ({ ...i, vdesc: num(i.vdesc) })),
      pag: comPag() ? st.pag.map((p) => ({ tpag: p.tpag, valor: num(p.valor) })) : [], dest: st.dest,
      refs: $('ref') && $('ref').value ? [dig($('ref').value)] : [], inf_cpl: $('inf_cpl').value.trim(), natop: $('natop') ? $('natop').value.trim() : '', dt_emissao: $('dt_emissao') ? $('dt_emissao').value : '',
      mod_frete: $('mod_frete') ? $('mod_frete').value : 9, vfrete: $('vfrete') ? num($('vfrete').value) : 0,
      volume: $('qvol') ? { qvol: $('qvol').value, pesob: num($('pesob').value), pesol: num($('pesob').value) } : null,
    };
  }
  async function enviar(transmitir, nova) {
    const d = coletar();
    if (transmitir) {
      const falta = [];
      if (!d.itens.length) falta.push('produtos');
      if (ini.modelo === 55 && !(d.dest && d.dest.cmun)) falta.push('o cliente (com endereço)');
      if (d.itens.some((i) => i.alerta)) falta.push('NCM/CEST de produtos marcados em vermelho (corrija no cadastro)');
      if (comPag() && d.pag.reduce((s, p) => s + p.valor, 0) + 0.001 < totais().total) falta.push('o pagamento completo');
      if (falta.length) return alert('Para emitir, falta: ' + falta.join(', ') + '.');
    }
    d.transmitir = transmitir; d.nova_apos = !!nova;
    document.querySelectorAll('.barra-final button').forEach((b) => b.disabled = true);
    try {
      const r = await (await fetch('/nfes/salvar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d) })).json();
      if (r.erro) { alert(r.erro); if (r.id) ini.id = r.id; }
      else { if (r.imprimir) window.open(r.imprimir, '_blank'); location = r.url; return; }
    } catch (e) { alert('Falha de comunicação com o servidor: ' + e); }
    document.querySelectorAll('.barra-final button').forEach((b) => b.disabled = false);
  }
  $('bt-previa').onclick = async () => {
    const d = coletar();
    if (!d.itens.length) return alert('Adicione pelo menos um produto para pré-visualizar.');
    const bt = $('bt-previa'); bt.disabled = true;
    const jan = window.open('', '_blank');
    try {
      const resp = await fetch('/nfes/previa', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d) });
      if (!resp.ok) { if (jan) jan.close(); const r = await resp.json().catch(() => ({})); alert(r.erro || 'Não foi possível gerar a pré-visualização.'); }
      else { const url = URL.createObjectURL(await resp.blob()); if (jan) jan.location = url; else window.open(url, '_blank'); }
    } catch (e) { if (jan) jan.close(); alert('Falha de comunicação com o servidor: ' + e); }
    bt.disabled = false;
  };
  $('bt-salvar').onclick = () => enviar(false);
  $('bt-emitir').onclick = () => enviar(true);
  if ($('bt-emitir-nova')) { $('bt-emitir-nova').onclick = () => enviar(true, true); document.addEventListener('keydown', (e) => { if (e.key === 'F9') { e.preventDefault(); enviar(true, true); } }); }

  // ---------- carregar ----------
  if ($('natureza')) $('natureza').value = d0.natureza || 'venda';
  if ($('ref') && d0.refs && d0.refs[0]) $('ref').value = d0.refs[0];
  $('inf_cpl').value = d0.inf_cpl || '';
  if ($('natop')) $('natop').value = d0.natop || '';
  if ($('dt_emissao')) $('dt_emissao').value = d0.dt_emissao || '';
  if ($('mod_frete')) { $('mod_frete').value = d0.mod_frete ?? 9; $('vfrete').value = d0.vfrete ? dec(d0.vfrete) : ''; const v = d0.volume || {}; $('qvol').value = v.qvol || ''; $('pesob').value = v.pesob ? dec(v.pesob, 3) : ''; }
  if (st.dest) { mostrarCli(); preencherCli(st.dest); if (ini.modelo === 65) bc.value = st.dest.doc || ''; } else mostrarCli();
  render(); ajustarNat();
})();
