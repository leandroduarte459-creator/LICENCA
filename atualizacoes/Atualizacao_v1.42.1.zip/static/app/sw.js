// Cavalcante Soluções: os dados sempre vêm do servidor; só a tela "sem conexão" fica guardada.
const C = 'cs-1.8.8';
const OFF = '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sem conexão</title><body style="font-family:system-ui;background:#0a5c45;color:#fff;display:grid;place-items:center;min-height:100vh;margin:0;text-align:center;padding:20px"><div><h1>Sem conexão com o servidor</h1><p>Verifique a rede do escritório (ou o Tailscale) e tente de novo.</p><button onclick="location.reload()" style="font-size:1rem;padding:12px 22px;border:0;border-radius:8px;background:#f2b705;font-weight:700">Tentar de novo</button></div>';
self.addEventListener('install', e => { self.skipWaiting(); e.waitUntil(caches.open(C).then(c => c.addAll(['/static/estilo.css', '/static/marca.svg']))); });
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(k => Promise.all(k.filter(n => n !== C).map(n => caches.delete(n)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  if (e.request.mode === 'navigate')
    e.respondWith(fetch(e.request).catch(() => new Response(OFF, {headers: {'Content-Type': 'text/html; charset=utf-8'}})));
});
